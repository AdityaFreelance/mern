# Environment variables for the client side code

REACT_APP_STRIPE_PUBLISHABLE_KEY = `Stripe publishable key for accepting payments`

REACT_APP_BASE_URL = `URL for the server APIs`
